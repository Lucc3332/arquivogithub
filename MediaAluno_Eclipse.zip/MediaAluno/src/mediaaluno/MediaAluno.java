package mediaaluno;

import java.util.Scanner;

public class MediaAluno {

    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);

        double nota1, nota2, nota3, media;

        System.out.println("===== CALCULO DA MEDIA DO ALUNO =====");

        System.out.print("Digite a primeira nota: ");
        nota1 = entrada.nextDouble();

        System.out.print("Digite a segunda nota: ");
        nota2 = entrada.nextDouble();

        System.out.print("Digite a terceira nota: ");
        nota3 = entrada.nextDouble();

        media = (nota1 + nota2 + nota3) / 3;

        System.out.printf("\nMedia do aluno: %.2f\n", media);

        if (media >= 7) {
            System.out.println("Aluno aprovado!");
        }
        else if (media >= 5) {
            System.out.println("Aluno de recuperacao!");
        }
        else {
            System.out.println("Aluno reprovado!");
        }

        entrada.close();
    }
}
